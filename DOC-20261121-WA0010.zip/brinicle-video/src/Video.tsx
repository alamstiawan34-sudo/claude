import React from 'react';
import {AbsoluteFill, Audio, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {ThreeCanvas} from '@remotion/three';
import {useThree} from '@react-three/fiber';
import {World} from './World';
import {Overlay} from './Overlay';
import {V3, cameraAt, seg} from './timeline';

const CameraRig: React.FC<{pos: V3; look: V3}> = ({pos, look}) => {
  const {camera} = useThree();
  camera.position.set(pos[0], pos[1], pos[2]);
  camera.lookAt(look[0], look[1], look[2]);
  camera.updateMatrixWorld();
  return null;
};

const Backdrop: React.FC<{t: number}> = ({t}) => {
  if (t < 3.15) {
    const drift = Math.sin(t * 1.2) * 40;
    return (
      <AbsoluteFill style={{background: 'linear-gradient(180deg,#120d3a 0%,#3b2a7a 38%,#c8587c 62%,#ffb27a 78%)'}}>
        <div style={{position: 'absolute', left: -200 + drift, top: 120, width: 1100, height: 380, borderRadius: '50%', background: 'radial-gradient(ellipse, rgba(90,255,190,0.55), rgba(90,255,190,0) 70%)', filter: 'blur(30px)', transform: 'rotate(-8deg)'}} />
        <div style={{position: 'absolute', left: 300 - drift, top: 260, width: 900, height: 300, borderRadius: '50%', background: 'radial-gradient(ellipse, rgba(150,120,255,0.5), rgba(150,120,255,0) 70%)', filter: 'blur(30px)', transform: 'rotate(10deg)'}} />
      </AbsoluteFill>
    );
  }
  return <AbsoluteFill style={{background: 'linear-gradient(180deg,#1a86b8 0%,#0d5a8a 25%,#0a3354 60%,#06213a 100%)'}} />;
};

export const BrinicleVideo: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps, width, height, durationInFrames} = useVideoConfig();
  const t = frame / fps;
  const cam = cameraAt(t);
  void seg;
  return (
    <AbsoluteFill style={{background: '#000'}}>
      <Audio src={staticFile('narasi.mp3')} />
      <Backdrop t={t} />
      <ThreeCanvas
        width={width}
        height={height}
        flat
        camera={{fov: 52, near: 0.1, far: 600, position: [0, 0, 10]}}
        style={{position: 'absolute', inset: 0}}
      >
        <CameraRig pos={cam.pos} look={cam.look} />
        <World t={t} />
      </ThreeCanvas>
      <Overlay t={t} frame={frame} total={durationInFrames} />
    </AbsoluteFill>
  );
};
