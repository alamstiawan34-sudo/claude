import React from 'react';
import {AbsoluteFill, spring, useVideoConfig} from 'remotion';
import '@fontsource/fredoka/latin-600.css';
import '@fontsource/fredoka/latin-700.css';
import {CUES, CUTS, clamp01, lerp, seg} from './timeline';

const fontFamily = "'Fredoka', 'Arial Rounded MT Bold', sans-serif";

const INK = '#0b2a4a';
const stroke = (w: number): React.CSSProperties => ({
  WebkitTextStroke: `${w}px ${INK}`,
  paintOrder: 'stroke fill',
});

const usePop = (frame: number, startFrame: number) => {
  const {fps} = useVideoConfig();
  return spring({frame: frame - startFrame, fps, config: {damping: 11, stiffness: 190, mass: 0.6}});
};

const Pill: React.FC<{frame: number; start: number; children: React.ReactNode; top?: number; bg?: string; color?: string}> = ({
  frame, start, children, top = 150, bg = '#ffffff', color = INK,
}) => {
  const s = usePop(frame, start);
  return (
    <div style={{position: 'absolute', top, left: 0, right: 0, display: 'flex', justifyContent: 'center', transform: `scale(${s})`}}>
      <div style={{background: bg, color, fontFamily, fontWeight: 700, fontSize: 46, padding: '18px 40px', borderRadius: 60, border: `8px solid ${INK}`, boxShadow: `0 10px 0 ${INK}`}}>
        {children}
      </div>
    </div>
  );
};

const Subtitle: React.FC<{t: number; frame: number}> = ({t, frame}) => {
  const idx = CUES.findIndex((c) => t >= c.s && t < c.e + 0.12);
  if (idx < 0 || t >= 74.74) return null;
  const cue = CUES[idx];
  const s = usePop(frame, Math.round(cue.s * 30));
  return (
    <div key={idx} style={{position: 'absolute', left: 60, right: 60, bottom: 250, display: 'flex', justifyContent: 'center', transform: `scale(${lerp(0.85, 1, clamp01(s))})`, opacity: clamp01(s * 1.5)}}>
      <div style={{fontFamily, fontWeight: 700, fontSize: 58, lineHeight: 1.18, textAlign: 'center', color: '#fff', ...stroke(14), textShadow: `0 8px 0 ${INK}`}}>
        {cue.text}
      </div>
    </div>
  );
};

const TitleCard: React.FC<{t: number; frame: number}> = ({t, frame}) => {
  if (t < 10.85 || t > 16.1) return null;
  const a = usePop(frame, Math.round(10.85 * 30));
  const b = usePop(frame, Math.round(13.27 * 30));
  const shake = Math.sin(frame * 1.7) * 1.2;
  return (
    <AbsoluteFill style={{alignItems: 'center', paddingTop: 230}}>
      <div style={{fontFamily, fontWeight: 700, fontSize: 200, color: '#fff', ...stroke(22), textShadow: `0 16px 0 ${INK}`, transform: `rotate(-3deg) scale(${a})`}}>
        Brinicle
      </div>
      {t >= 13.27 && (
        <div style={{fontFamily, fontWeight: 700, fontSize: 104, color: '#bff3ff', ...stroke(18), textShadow: `0 12px 0 ${INK}`, transform: `rotate(${2 + shake * 0.3}deg) scale(${b})`, marginTop: 10, whiteSpace: 'nowrap'}}>
          Jari Es Kematian
        </div>
      )}
    </AbsoluteFill>
  );
};

const Thermometer: React.FC<{t: number; frame: number}> = ({t, frame}) => {
  if (t < 27.1 || t > 33.45) return null;
  const s = usePop(frame, Math.round(27.1 * 30));
  const drop = seg(t, 29.6, 32);
  const H = 640;
  const fill = lerp(0.5, 0.08, drop) * H;
  return (
    <div style={{position: 'absolute', right: 40, top: 300, transform: `scale(${s})`, transformOrigin: 'top right', display: 'flex', gap: 16, alignItems: 'flex-end', fontFamily, fontWeight: 700, color: INK}}>
      <div style={{background: '#fff', border: `8px solid ${INK}`, borderRadius: 24, padding: '14px 18px', fontSize: 34, width: 250, boxShadow: `0 8px 0 ${INK}`}}>
        Air laut beku di sekitar −1,9°C
      </div>
      <div style={{width: 70, height: H, background: '#fff', border: `8px solid ${INK}`, borderRadius: 40, position: 'relative', overflow: 'hidden', boxShadow: `0 8px 0 ${INK}`}}>
        <div style={{position: 'absolute', bottom: 0, left: 0, right: 0, height: fill, background: 'linear-gradient(#5bc8ff,#2f5bff)', borderRadius: 30}} />
        <div style={{position: 'absolute', left: 0, right: 0, bottom: H * 0.5, height: 6, background: INK}} />
      </div>
    </div>
  );
};

const Step: React.FC<{t: number; frame: number}> = ({t, frame}) => {
  const steps: {s: number; e: number; text: string}[] = [
    {s: 16.2, e: 18.15, text: 'Laut kutub'},
    {s: 18.15, e: 23.04, text: 'Es yang terbentuk tidak mengandung garam'},
    {s: 23.04, e: 27.1, text: 'Garam menumpuk jadi air asin pekat'},
    {s: 27.1, e: 33.45, text: 'Air asin lebih dingin dari es di sekitarnya'},
  ];
  const cur = steps.find((x) => t >= x.s && t < x.e);
  if (!cur) return null;
  return (
    <Pill key={cur.s} frame={frame} start={Math.round(cur.s * 30)} top={150}>
      {cur.text}
    </Pill>
  );
};

const Viewfinder: React.FC<{t: number}> = ({t}) => {
  if (t < 60.8 || t > 70.2) return null;
  const rel = t - 60.8;
  const tc = `00:00:${String(Math.floor(rel)).padStart(2, '0')}:${String(Math.floor((rel % 1) * 30)).padStart(2, '0')}`;
  const corner = (style: React.CSSProperties): React.CSSProperties => ({position: 'absolute', width: 90, height: 90, border: '0 solid #fff', ...style});
  return (
    <AbsoluteFill>
      <div style={corner({top: 90, left: 60, borderTopWidth: 10, borderLeftWidth: 10})} />
      <div style={corner({top: 90, right: 60, borderTopWidth: 10, borderRightWidth: 10})} />
      <div style={corner({bottom: 90, left: 60, borderBottomWidth: 10, borderLeftWidth: 10})} />
      <div style={corner({bottom: 90, right: 60, borderBottomWidth: 10, borderRightWidth: 10})} />
      <div style={{position: 'absolute', top: 120, left: 100, display: 'flex', alignItems: 'center', gap: 16, fontFamily, fontWeight: 700, fontSize: 44, color: '#fff', ...stroke(8)}}>
        <div style={{width: 34, height: 34, borderRadius: 20, background: Math.sin(t * 6) > 0 ? '#ff3b3b' : '#702020', border: `5px solid ${INK}`}} />
        REC
      </div>
      <div style={{position: 'absolute', top: 124, right: 100, fontFamily, fontWeight: 700, fontSize: 40, color: '#fff', ...stroke(8)}}>{tc}</div>
      <div style={{position: 'absolute', inset: 0, boxShadow: 'inset 0 0 260px rgba(0,20,40,0.55)'}} />
    </AbsoluteFill>
  );
};

const Contrast: React.FC<{t: number; frame: number}> = ({t, frame}) => {
  const first = t >= 70.2 && t < 72.1;
  const second = t >= 72.22 && t < 74.5;
  const f1 = usePop(frame, Math.round(70.2 * 30));
  const f2 = usePop(frame, Math.round(72.22 * 30));
  if (!first && !second) return null;
  return (
    <AbsoluteFill style={{alignItems: 'center', paddingTop: 260}}>
      {first && (
        <div style={{fontFamily, fontWeight: 700, fontSize: 130, color: '#fff3b0', ...stroke(20), textShadow: `0 14px 0 ${INK}`, transform: `rotate(-2deg) scale(${f1})`}}>
          Seindah ini
        </div>
      )}
      {second && (
        <div style={{fontFamily, fontWeight: 700, fontSize: 116, color: '#ff8a8a', ...stroke(20), textShadow: `0 14px 0 ${INK}`, transform: `rotate(2deg) scale(${f2})`, whiteSpace: 'nowrap'}}>
          Semematikan ini
        </div>
      )}
    </AbsoluteFill>
  );
};

const Cta: React.FC<{t: number; frame: number}> = ({t, frame}) => {
  const a = usePop(frame, Math.round(74.74 * 30));
  const b = usePop(frame, Math.round(78.28 * 30));
  if (t < 74.74) return null;
  return (
    <>
      <div style={{position: 'absolute', top: 230, left: 80, right: 80, transform: `scale(${a})`}}>
        <div style={{background: '#fff', border: `10px solid ${INK}`, borderRadius: 70, padding: '40px 50px', fontFamily, fontWeight: 700, fontSize: 62, lineHeight: 1.15, color: INK, textAlign: 'center', boxShadow: `0 14px 0 ${INK}`}}>
          Fenomena alam apa lagi yang belum pernah kamu dengar?
        </div>
        <div style={{width: 0, height: 0, marginLeft: 150, borderLeft: '40px solid transparent', borderRight: '40px solid transparent', borderTop: `70px solid ${INK}`}} />
      </div>
      {t >= 78.28 && (
        <div style={{position: 'absolute', bottom: 260, left: 0, right: 0, display: 'flex', justifyContent: 'center', transform: `scale(${b})`}}>
          <div style={{background: '#ffd84d', border: `10px solid ${INK}`, borderRadius: 80, padding: '26px 60px', fontFamily, fontWeight: 700, fontSize: 64, color: INK, boxShadow: `0 12px 0 ${INK}`, display: 'flex', alignItems: 'center', gap: 22}}>
            Tulis di kolom komentar!
            <span style={{display: 'flex', gap: 8}}>
              {[0, 1, 2].map((i) => (
                <span key={i} style={{width: 18, height: 18, borderRadius: 10, background: INK, transform: `translateY(${Math.sin(frame * 0.4 + i) * -8}px)`}} />
              ))}
            </span>
          </div>
        </div>
      )}
    </>
  );
};

export const Overlay: React.FC<{t: number; frame: number; total: number}> = ({t, frame, total}) => {
  const near = CUTS.map((c) => t - c).filter((d) => d >= 0 && d < 0.25);
  const flash = near.length ? 1 - near[0] / 0.25 : 0;
  const fadeIn = 1 - clamp01(frame / 8);
  const fadeOut = clamp01((frame - (total - 10)) / 10);
  return (
    <AbsoluteFill>
      <Step t={t} frame={frame} />
      <TitleCard t={t} frame={frame} />
      <Thermometer t={t} frame={frame} />
      <Contrast t={t} frame={frame} />
      <Viewfinder t={t} />
      <Cta t={t} frame={frame} />
      <Subtitle t={t} frame={frame} />
      <AbsoluteFill style={{background: '#e6fbff', opacity: flash * 0.8}} />
      <AbsoluteFill style={{background: '#000', opacity: Math.max(fadeIn, fadeOut)}} />
    </AbsoluteFill>
  );
};
