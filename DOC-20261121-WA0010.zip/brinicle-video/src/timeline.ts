export const FPS = 30;
// Durasi audio narasi (ffprobe): 79.647313 detik -> 2390 frame
export const AUDIO_SECONDS = 79.647313;
export const DURATION_IN_FRAMES = Math.ceil(AUDIO_SECONDS * FPS);

export const FLOOR = -14; // dasar laut
export const X0 = 40; // posisi "ruang potongan" (cutaway) untuk penjelasan garam

export type V3 = [number, number, number];

export const clamp01 = (x: number) => Math.min(1, Math.max(0, x));
export const lerp = (a: number, b: number, p: number) => a + (b - a) * p;
export const seg = (t: number, a: number, b: number) => clamp01((t - a) / (b - a));
export const easeInOut = (p: number) => 0.5 - 0.5 * Math.cos(Math.PI * clamp01(p));
export const easeOut = (p: number) => 1 - Math.pow(1 - clamp01(p), 3);
export const mixV = (a: V3, b: V3, p: number): V3 => [
  lerp(a[0], b[0], p),
  lerp(a[1], b[1], p),
  lerp(a[2], b[2], p),
];

// Titik potong adegan (untuk efek kilat transisi)
export const CUTS = [3.15, 10.85, 16.2, 33.45, 46.86, 57.48, 60.8, 70.2, 74.74];

// Subtitle: waktu diambil dari jeda sunyi pada audio (silencedetect)
export type Cue = {s: number; e: number; text: string};
export const CUES: Cue[] = [
  {s: 0.1, e: 2.7, text: 'Bayangkan ada sebuah jari es raksasa...'},
  {s: 3.15, e: 6.8, text: 'yang turun perlahan dari permukaan laut menuju dasar samudra.'},
  {s: 7.4, e: 9.1, text: 'Dan apa pun yang disentuhnya...'},
  {s: 9.68, e: 10.2, text: 'membeku.'},
  {s: 10.85, e: 12.85, text: 'Fenomena ini disebut brinicle.'},
  {s: 13.27, e: 15.67, text: 'Julukannya: Jari Es Kematian.'},
  {s: 16.2, e: 17.7, text: 'Semuanya berawal di kutub.'},
  {s: 18.15, e: 22.62, text: 'Saat air laut membeku di permukaan, garamnya tidak ikut masuk ke dalam es.'},
  {s: 23.04, e: 26.7, text: 'Garam itu terperas keluar, menjadi air asin yang sangat pekat.'},
  {s: 27.1, e: 29.6, text: 'Dan air asin ini luar biasa dingin!'},
  {s: 29.6, e: 33.02, text: 'Suhunya jauh di bawah titik beku air laut di sekitarnya.'},
  {s: 33.45, e: 36.5, text: 'Karena lebih berat, air super dingin ini tenggelam.'},
  {s: 36.88, e: 40.8, text: 'Dan di sepanjang jalurnya, air laut di sekelilingnya langsung membeku,'},
  {s: 40.8, e: 43.87, text: 'membentuk tabung es yang terus memanjang ke bawah.'},
  {s: 44.46, e: 45.1, text: 'Perlahan...'},
  {s: 45.56, e: 46.26, text: 'tapi pasti.'},
  {s: 46.86, e: 49.55, text: 'Ketika tabung es itu akhirnya menyentuh dasar laut,'},
  {s: 49.97, e: 51.88, text: 'ia menyebar seperti jaring beku.'},
  {s: 52.4, e: 54.98, text: 'Bintang laut dan bulu babi yang bergerak lambat...'},
  {s: 55.42, e: 56.9, text: 'tidak sempat melarikan diri.'},
  {s: 57.48, e: 58.92, text: 'Mereka terjebak,'},
  {s: 59.45, e: 60.25, text: 'lalu membeku.'},
  {s: 60.8, e: 64.1, text: 'Fenomena ini pertama kali terekam kamera dalam dokumenter BBC,'},
  {s: 64.1, e: 69.74, text: 'dan hingga kini masih jadi salah satu pemandangan paling langka di bawah laut kutub.'},
  {s: 70.2, e: 71.86, text: 'Alam bisa seindah ini...'},
  {s: 72.22, e: 74.18, text: 'sekaligus semematikan ini.'},
];

// ---------- Pertumbuhan brinicle (0..1 dari panjang penuh) ----------
export const TUBE_LEN = 14; // panjang penuh = jarak es -> dasar laut
export const growth = (t: number) => {
  if (t < 3.15) return 0;
  if (t < 33.45) return 0.26 * easeInOut(seg(t, 3.15, 10.2));
  const p = seg(t, 33.45, 46.86);
  return 0.26 + 0.74 * (1 - Math.pow(1 - p, 1.8));
};
export const tipY = (t: number) => -growth(t) * TUBE_LEN;

// ---------- Jaring es di dasar laut ----------
export const T_TOUCH = 46.86;
export const webR = (t: number) => {
  const p = seg(t, T_TOUCH, 58.2);
  return 6.6 * (1 - Math.pow(1 - p, 2.2));
};

export type CreatureDef = {
  kind: 'star' | 'urchin';
  a: number;
  r0: number;
  color: string;
  size: number;
  phase: number;
};
export const CREATURES: CreatureDef[] = [
  {kind: 'star', a: 0.5, r0: 2.3, color: '#ff8a5b', size: 0.8, phase: 0},
  {kind: 'star', a: 2.4, r0: 3.0, color: '#ffb347', size: 0.75, phase: 1.3},
  {kind: 'urchin', a: 4.0, r0: 2.6, color: '#9a78e0', size: 0.55, phase: 2.1},
  {kind: 'star', a: 5.3, r0: 3.6, color: '#ff6f91', size: 0.7, phase: 0.7},
  {kind: 'urchin', a: 1.5, r0: 3.9, color: '#6f8cf0', size: 0.5, phase: 3.3},
  {kind: 'urchin', a: 3.2, r0: 4.4, color: '#c07de0', size: 0.6, phase: 4.1},
];
const SPEED = 0.08; // makhluk berusaha kabur pelan-pelan

const freezeTime = (c: CreatureDef) => {
  let r = c.r0;
  for (let s = T_TOUCH; s < 70; s += 0.05) {
    if (webR(s) >= r) return s;
    r += SPEED * 0.05;
  }
  return 70;
};
export const FREEZE_T = CREATURES.map(freezeTime);

export const creatureState = (i: number, t: number) => {
  const c = CREATURES[i];
  const tf = FREEZE_T[i];
  const r = c.r0 + SPEED * Math.min(Math.max(t - T_TOUCH, 0), tf - T_TOUCH);
  const frozen = seg(t, tf, tf + 0.8);
  const moving = t > T_TOUCH && frozen < 1;
  const pos: V3 = [Math.cos(c.a) * r, FLOOR + 0.12 + c.size * 0.3, Math.sin(c.a) * r];
  return {pos, frozen, moving, r};
};

// ---------- Kamera ----------
export type Cam = {pos: V3; look: V3};
const orbit = (R: number, a: number, y: number): V3 => [R * Math.sin(a), y, R * Math.cos(a)];

export const cameraAt = (t: number): Cam => {
  // 1) Permukaan es
  if (t < 3.15) {
    const p = easeInOut(t / 3.15);
    return {pos: mixV([0, 3.5, 15], [0, 3.0, 12.2], p), look: [0, 2.6, -6]};
  }
  // 2) Menyelam ke bawah es
  if (t < 7.4) {
    const p = easeInOut(seg(t, 3.15, 7.4));
    return {
      pos: mixV([2.2, -0.8, 5.5], [3.8, -4.2, 6.2], p),
      look: mixV([0, -1.5, 0], [0.1, tipY(t) - 0.8, 0], p),
    };
  }
  // 3) Ubur-ubur menyentuh ujung brinicle
  if (t < 10.85) {
    const p = easeInOut(seg(t, 7.4, 10.85));
    return {pos: mixV([3.8, -4.2, 6.2], [2.4, -4.2, 4.6], p), look: [0.1, tipY(t) - 0.8, 0]};
  }
  // 4) Orbit lebar: judul
  if (t < 16.2) {
    const a = lerp(0.9, -0.7, seg(t, 10.85, 16.2));
    return {pos: orbit(11, a, -4.5), look: [0, -5.2, 0]};
  }
  // 5) Potongan: es membeku & garam terperas
  if (t < 27.1) {
    const p = easeInOut(seg(t, 16.2, 27.1));
    return {pos: mixV([X0, 0.9, 10], [X0, 0.3, 8], p), look: mixV([X0, 0.1, 0], [X0, -0.2, 0], p)};
  }
  // 6) Air asin pekat menetes
  if (t < 33.45) {
    const p = easeInOut(seg(t, 27.1, 33.45));
    return {pos: mixV([X0, 0.8, 9], [X0 + 0.6, -0.9, 6.8], p), look: mixV([X0, 0.7, 0], [X0, -1.2, 0], p)};
  }
  // 7) Mengikuti ujung brinicle yang memanjang
  if (t < T_TOUCH) {
    const ty = tipY(t);
    const R = lerp(9.5, 6.5, easeInOut(seg(t, 33.45, T_TOUCH)));
    const a = 0.5 + 0.05 * (t - 33.45);
    const cy = Math.max(ty + 1.0, -11.8);
    return {pos: orbit(R, a, cy), look: [0, Math.max(ty + 1.4, -12.6), 0]};
  }
  // 8) Dasar laut: jaring es menyebar
  if (t < 57.48) {
    const a = lerp(0.7, -0.3, seg(t, T_TOUCH, 57.48));
    return {pos: orbit(15, a, -10.2), look: [0, -12.7, 0]};
  }
  // 9) Close-up bintang laut yang membeku
  if (t < 60.8) {
    const h = creatureState(1, t).pos;
    const a = lerp(0.5, 0.9, seg(t, 57.48, 60.8));
    return {
      pos: [h[0] + 5.2 * Math.sin(a), h[1] + 1.7, h[2] + 5.2 * Math.cos(a)],
      look: [h[0], h[1] + 0.25, h[2]],
    };
  }
  // 10) Kamera dokumenter
  if (t < 70.2) {
    const p = easeInOut(seg(t, 60.8, 70.2));
    return {pos: mixV([9.5, -8.6, 9.5], [8.2, -8.0, 7.6], p), look: mixV([1.2, -9.6, 0], [0.8, -9.0, 0], p)};
  }
  // 11) Menjauh: seindah & semematikan
  if (t < 74.74) {
    const p = easeInOut(seg(t, 70.2, 74.74));
    return {pos: mixV([3, -12, 15], [0, -3, 23], p), look: mixV([0, -9, 0], [0, -6.5, 0], p)};
  }
  // 12) Penutup
  const a = lerp(-0.35, 0.35, seg(t, 74.74, 79.7));
  return {pos: orbit(22, a, -4.5), look: [0, -6.5, 0]};
};
