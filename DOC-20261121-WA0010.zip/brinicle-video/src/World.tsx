import React, {useMemo} from 'react';
import * as THREE from 'three';
import {
  CREATURES,
  FLOOR,
  TUBE_LEN,
  V3,
  X0,
  clamp01,
  creatureState,
  easeInOut,
  easeOut,
  growth,
  lerp,
  seg,
  tipY,
  webR,
} from './timeline';

// ---------- Bahan toon ----------
const gradientMap = (() => {
  const data = new Uint8Array([80, 150, 215, 255]);
  const tex = new THREE.DataTexture(data, 4, 1, THREE.RedFormat);
  tex.minFilter = THREE.NearestFilter;
  tex.magFilter = THREE.NearestFilter;
  tex.generateMipmaps = false;
  tex.needsUpdate = true;
  return tex;
})();

const INK = '#071a2b';

type ToonProps = {
  color: string;
  emissive?: string;
  opacity?: number;
  outline?: number;
  hull?: V3;
  position?: V3;
  rotation?: V3;
  scale?: V3 | number;
  children: React.ReactNode;
};

// Mesh toon + garis tepi tebal (inverted hull)
const Toon: React.FC<ToonProps> = ({
  color,
  emissive = '#000000',
  opacity = 1,
  outline = 0.07,
  hull,
  position,
  rotation,
  scale,
  children,
}) => {
  const hs: V3 = hull ?? [1 + outline, 1 + outline, 1 + outline];
  return (
    <group position={position} rotation={rotation} scale={scale as any}>
      <mesh>
        {children}
        <meshToonMaterial
          color={color}
          emissive={emissive}
          gradientMap={gradientMap}
          transparent={opacity < 1}
          opacity={opacity}
        />
      </mesh>
      {opacity >= 0.95 && outline > 0 ? (
        <mesh scale={hs}>
          {children}
          <meshBasicMaterial color={INK} side={THREE.BackSide} />
        </mesh>
      ) : null}
    </group>
  );
};

// ---------- Utilitas ----------
const rng = (seed: number) => {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
};

const mixColor = (a: string, b: string, p: number) =>
  '#' + new THREE.Color(a).lerp(new THREE.Color(b), clamp01(p)).getHexString();

// ---------- Brinicle ----------
const radiusAt = (d: number) =>
  0.3 + 0.55 * Math.exp(-d / 5) + 0.035 * Math.sin(d * 2.1) + 0.025 * Math.sin(d * 4.7 + 1);

const brinGeometry = (len: number, off: number) => {
  const pts: THREE.Vector2[] = [];
  const rEnd = radiusAt(len) + off;
  const capSteps = 6;
  for (let i = 0; i <= capSteps; i++) {
    const a = (i / capSteps) * (Math.PI / 2);
    pts.push(new THREE.Vector2(Math.sin(a) * rEnd, -len - Math.cos(a) * rEnd * 0.9));
  }
  const n = Math.max(2, Math.ceil(len / 0.35));
  for (let i = n - 1; i >= 0; i--) {
    const d = (i / n) * len;
    pts.push(new THREE.Vector2(radiusAt(d) + off, -d));
  }
  pts.push(new THREE.Vector2(radiusAt(0) + off + 0.3, 0.05));
  return new THREE.LatheGeometry(pts, 28);
};

const Brinicle: React.FC<{t: number}> = ({t}) => {
  const len = Math.max(0.05, growth(t) * TUBE_LEN);
  const geo = useMemo(() => brinGeometry(len, 0), [len]);
  const hullGeo = useMemo(() => brinGeometry(len, 0.075), [len]);
  const rings: number[] = [];
  for (let k = 1; k < 12; k++) {
    const d = 1.1 * k + 0.3 * Math.sin(k);
    if (d < len - 0.3) rings.push(d);
  }
  const ty = -len;
  const drops = 16;
  const fall = Math.max(0, Math.min(3.2, ty - FLOOR - 0.2));
  return (
    <group visible={growth(t) > 0}>
      <mesh geometry={geo}>
        <meshToonMaterial color="#c4e9f8" emissive="#0f3a52" gradientMap={gradientMap} />
      </mesh>
      <mesh geometry={hullGeo}>
        <meshBasicMaterial color={INK} side={THREE.BackSide} />
      </mesh>
      {rings.map((d, i) => (
        <mesh key={i} position={[0, -d, 0]} rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[radiusAt(d) + 0.02, 0.05, 6, 24]} />
          <meshToonMaterial color="#ffffff" gradientMap={gradientMap} emissive="#6fc7e8" />
        </mesh>
      ))}
      {/* tetesan air asin dingin yang jatuh dari ujung */}
      {Array.from({length: drops}).map((_, i) => {
        const ph = (t * 1.3 + i / drops) % 1;
        const a = i * 2.4;
        const r = 0.12 + 0.12 * ((i * 7) % 5) / 5;
        return (
          <mesh key={i} position={[Math.cos(a) * r, ty - 0.35 - ph * fall, Math.sin(a) * r]} scale={0.1 + 0.05 * ((i * 3) % 4) / 4}>
            <sphereGeometry args={[1, 8, 8]} />
            <meshBasicMaterial color="#aef3ff" transparent opacity={1 - ph} />
          </mesh>
        );
      })}
      <pointLight position={[0, ty - 0.6, 0]} color="#8fe8ff" intensity={4} distance={6} />
    </group>
  );
};

// ---------- Lapisan es (langit-langit laut) ----------
const IceCeiling: React.FC = () => {
  const bits = useMemo(() => {
    const r = rng(11);
    return Array.from({length: 34}).map(() => {
      const a = r() * Math.PI * 2;
      const d = 1.1 + r() * 9;
      return {x: Math.cos(a) * d, z: Math.sin(a) * d, h: 0.4 + r() * 1.1, w: 0.14 + r() * 0.2};
    });
  }, []);
  const mounds = useMemo(() => {
    const r = rng(5);
    return Array.from({length: 16}).map(() => ({
      x: (r() - 0.5) * 30,
      z: -12 + r() * 24,
      s: 0.8 + r() * 1.6,
    }));
  }, []);
  return (
    <group>
      <Toon color="#f2fbff" outline={0} position={[0, 0.6, 0]}>
        <boxGeometry args={[60, 1.2, 40]} />
      </Toon>
      {bits.map((b, i) => (
        <Toon key={i} color="#d9f4ff" outline={0.12} position={[b.x, -b.h / 2, b.z]} rotation={[Math.PI, 0, 0]}>
          <coneGeometry args={[b.w, b.h, 6]} />
        </Toon>
      ))}
      {mounds.map((m, i) => (
        <Toon key={i} color="#ffffff" outline={0.06} position={[m.x, 1.2, m.z]} scale={[m.s * 1.6, m.s * 0.6, m.s * 1.2]}>
          <icosahedronGeometry args={[1, 1]} />
        </Toon>
      ))}
    </group>
  );
};

const Surface: React.FC = () => (
  <group>
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 1.0, 0]}>
      <planeGeometry args={[600, 600]} />
      <meshToonMaterial color="#2b78b0" gradientMap={gradientMap} />
    </mesh>
    {[
      [-14, -30, 6, 9],
      [12, -42, 8, 12],
      [-26, -58, 10, 14],
      [30, -70, 9, 11],
    ].map(([x, z, r, h], i) => (
      <Toon key={i} color="#e9f7ff" outline={0.05} position={[x, h / 2, z]}>
        <coneGeometry args={[r, h, 6]} />
      </Toon>
    ))}
    <mesh position={[-9, 3.5, -90]}>
      <sphereGeometry args={[7, 24, 24]} />
      <meshBasicMaterial color="#ffd9a0" fog={false} />
    </mesh>
    <mesh position={[-9, 3.5, -91]}>
      <sphereGeometry args={[12, 24, 24]} />
      <meshBasicMaterial color="#ffb27a" transparent opacity={0.25} fog={false} />
    </mesh>
  </group>
);

// ---------- Ubur-ubur yang membeku ----------
const Jelly: React.FC<{t: number}> = ({t}) => {
  const p = easeInOut(seg(t, 5.8, 9.5));
  const f = seg(t, 9.5, 10.2);
  const y = lerp(-8.5, tipY(t) - 0.95, p);
  const x = 0.35 + 0.4 * Math.sin(t * 1.3) * (1 - p);
  const body = mixColor('#ff9ad5', '#d4f3ff', f);
  const tentacles = Array.from({length: 8});
  return (
    <group position={[x, y, 0]} visible={t > 5.8 && t < 33.45} scale={clamp01((t - 5.8) / 0.5) * 1}>
      <Toon color={body} emissive={mixColor('#8a2a6a', '#2a6a8a', f)} scale={[1, 0.78, 1]} outline={0.09}>
        <sphereGeometry args={[0.55, 20, 16]} />
      </Toon>
      <Toon color="#ffffff" position={[-0.18, 0.12, 0.45]} outline={0.2}>
        <sphereGeometry args={[0.09, 10, 10]} />
      </Toon>
      <Toon color="#ffffff" position={[0.18, 0.12, 0.45]} outline={0.2}>
        <sphereGeometry args={[0.09, 10, 10]} />
      </Toon>
      {tentacles.map((_, i) => {
        const a = (i / tentacles.length) * Math.PI * 2;
        const sway = Math.sin(t * 2.2 + i) * 0.25 * (1 - f);
        return (
          <group key={i} position={[Math.cos(a) * 0.32, -0.3, Math.sin(a) * 0.32]} rotation={[sway, 0, sway * 0.7]}>
            <mesh position={[0, -0.45, 0]}>
              <cylinderGeometry args={[0.035, 0.02, 0.9, 6]} />
              <meshToonMaterial color={body} gradientMap={gradientMap} />
            </mesh>
          </group>
        );
      })}
      {Array.from({length: 7}).map((_, i) => {
        const a = (i / 7) * Math.PI * 2;
        return (
          <mesh
            key={i}
            position={[Math.cos(a) * 0.55 * f, 0.1 + Math.sin(a * 2) * 0.2, Math.sin(a) * 0.55 * f]}
            rotation={[Math.sin(a) * 1.2, 0, -Math.cos(a) * 1.2]}
            scale={f}
          >
            <coneGeometry args={[0.1, 0.45, 5]} />
            <meshToonMaterial color="#e6fbff" gradientMap={gradientMap} emissive="#4aa6c8" />
          </mesh>
        );
      })}
    </group>
  );
};

// ---------- Makhluk dasar laut ----------
const starGeometry = (() => {
  const shape = new THREE.Shape();
  const pts = 5;
  for (let i = 0; i < pts * 2; i++) {
    const a = (i / (pts * 2)) * Math.PI * 2 + Math.PI / 2;
    const r = i % 2 === 0 ? 1 : 0.52;
    const x = Math.cos(a) * r;
    const y = Math.sin(a) * r;
    if (i === 0) shape.moveTo(x, y);
    else shape.lineTo(x, y);
  }
  shape.closePath();
  const g = new THREE.ExtrudeGeometry(shape, {
    depth: 0.28,
    bevelEnabled: true,
    bevelThickness: 0.12,
    bevelSize: 0.1,
    bevelSegments: 3,
  });
  g.center();
  return g;
})();

const Eye: React.FC<{position: V3; s?: number}> = ({position, s = 1}) => (
  <group position={position} scale={s}>
    <mesh>
      <sphereGeometry args={[0.13, 12, 12]} />
      <meshBasicMaterial color="#ffffff" />
    </mesh>
    <mesh position={[0, -0.01, 0.09]}>
      <sphereGeometry args={[0.07, 10, 10]} />
      <meshBasicMaterial color={INK} />
    </mesh>
  </group>
);

const Creature: React.FC<{i: number; t: number}> = ({i, t}) => {
  const c = CREATURES[i];
  const st = creatureState(i, t);
  const col = mixColor(c.color, '#d9f3ff', st.frozen);
  const bob = st.moving ? Math.abs(Math.sin(t * 6 + c.phase)) * 0.07 : 0;
  const yaw = -c.a + Math.PI / 2 + (st.moving ? Math.sin(t * 5 + c.phase) * 0.12 : Math.sin(t * 0.8 + c.phase) * 0.15);
  const spikes = useMemo(() => {
    const out: {q: THREE.Quaternion; d: THREE.Vector3}[] = [];
    const n = 30;
    for (let k = 0; k < n; k++) {
      const yy = 1 - (k / (n - 1)) * 2;
      const rr = Math.sqrt(1 - yy * yy);
      const th = k * 2.399963;
      const d = new THREE.Vector3(Math.cos(th) * rr, Math.abs(yy) * 0.9 + 0.1, Math.sin(th) * rr).normalize();
      const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), d);
      out.push({q, d});
    }
    return out;
  }, []);
  return (
    <group position={[st.pos[0], st.pos[1] + bob, st.pos[2]]} rotation={[0, yaw, 0]} scale={c.size}>
      {c.kind === 'star' ? (
        <group rotation={[-Math.PI / 2, 0, 0]}>
          <Toon color={col} outline={0.06} hull={[1.07, 1.07, 1.25]}>
            <primitive object={starGeometry} attach="geometry" />
          </Toon>
          <group position={[0, 0, 0.3]}>
            <Eye position={[-0.2, 0.12, 0]} />
            <Eye position={[0.2, 0.12, 0]} />
          </group>
        </group>
      ) : (
        <group position={[0, 0.45, 0]}>
          <Toon color={col} outline={0.07}>
            <sphereGeometry args={[0.6, 18, 14]} />
          </Toon>
          {spikes.map((s, k) => (
            <mesh key={k} position={s.d.clone().multiplyScalar(0.62).toArray()} quaternion={s.q}>
              <coneGeometry args={[0.07, 0.55, 6]} />
              <meshToonMaterial color={mixColor('#4b3a8a', '#b7e6f5', st.frozen)} gradientMap={gradientMap} />
            </mesh>
          ))}
          <Eye position={[-0.22, 0.12, 0.66]} />
          <Eye position={[0.22, 0.12, 0.66]} />
        </group>
      )}
      <mesh position={[0, c.kind === 'star' ? 0.1 : 0.45, 0]} scale={st.frozen * 1.45 + 0.001} visible={st.frozen > 0.01}>
        <icosahedronGeometry args={[0.9, 1]} />
        <meshToonMaterial color="#cdf2ff" gradientMap={gradientMap} transparent opacity={0.55} emissive="#3f9fc2" />
      </mesh>
    </group>
  );
};

const Floor: React.FC = () => {
  const rocks = useMemo(() => {
    const r = rng(21);
    return Array.from({length: 14}).map(() => {
      const a = r() * Math.PI * 2;
      const d = 7 + r() * 16;
      return {x: Math.cos(a) * d, z: Math.sin(a) * d, s: 0.5 + r() * 1.4, c: r() > 0.5 ? '#5a7f98' : '#6b92ab'};
    });
  }, []);
  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, FLOOR, 0]}>
        <circleGeometry args={[70, 48]} />
        <meshToonMaterial color="#6fa8c2" gradientMap={gradientMap} />
      </mesh>
      {rocks.map((r, i) => (
        <Toon key={i} color={r.c} outline={0.06} position={[r.x, FLOOR + r.s * 0.3, r.z]} scale={[r.s * 1.3, r.s * 0.8, r.s]}>
          <dodecahedronGeometry args={[1, 0]} />
        </Toon>
      ))}
    </group>
  );
};

const Web: React.FC<{t: number}> = ({t}) => {
  const R = webR(t);
  if (R <= 0.01) return null;
  const spokes = 10;
  const crystals = Array.from({length: 7});
  return (
    <group position={[0, FLOOR, 0]}>
      <mesh position={[0, 0.05, 0]} scale={[R, 1, R]}>
        <cylinderGeometry args={[1, 1, 0.1, 40]} />
        <meshToonMaterial color="#e6fbff" gradientMap={gradientMap} transparent opacity={0.8} emissive="#3f9fc2" />
      </mesh>
      {Array.from({length: spokes}).map((_, i) => {
        const a = (i / spokes) * Math.PI * 2;
        return (
          <group key={i} rotation={[0, a, 0]}>
            <mesh position={[R / 2, 0.15, 0]}>
              <boxGeometry args={[R, 0.14, 0.16]} />
              <meshToonMaterial color="#ffffff" gradientMap={gradientMap} emissive="#6fc7e8" />
            </mesh>
            {crystals.map((_, k) => {
              const rr = ((k + 1) / 7) * 6.6;
              const g = clamp01((R - rr) / 0.8);
              return (
                <mesh key={k} position={[rr, 0.15 + 0.2 * g, 0]} scale={g + 0.001} visible={g > 0.01}>
                  <coneGeometry args={[0.13, 0.7, 5]} />
                  <meshToonMaterial color="#e9fbff" gradientMap={gradientMap} emissive="#4aa6c8" />
                </mesh>
              );
            })}
          </group>
        );
      })}
    </group>
  );
};

// ---------- Partikel melayang ----------
const Snow: React.FC<{t: number; center: V3; size: V3; n?: number}> = ({t, center, size, n = 70}) => {
  const items = useMemo(() => {
    const r = rng(3);
    return Array.from({length: n}).map(() => ({x: r(), y: r(), z: r(), s: 0.03 + r() * 0.05, v: 0.15 + r() * 0.3}));
  }, [n]);
  return (
    <group>
      {items.map((p, i) => {
        const yy = (((p.y - (t * p.v) / size[1]) % 1) + 1) % 1;
        return (
          <mesh
            key={i}
            position={[
              center[0] + (p.x - 0.5) * size[0] + Math.sin(t + i) * 0.1,
              center[1] + (yy - 0.5) * size[1],
              center[2] + (p.z - 0.5) * size[2],
            ]}
            scale={p.s}
          >
            <sphereGeometry args={[1, 6, 6]} />
            <meshBasicMaterial color="#e8fbff" transparent opacity={0.7} />
          </mesh>
        );
      })}
    </group>
  );
};

// ---------- Sinar matahari menembus es ----------
const Rays: React.FC<{t: number}> = ({t}) => {
  const o = seg(t, 66, 70.5) * 0.13;
  if (o <= 0.001) return null;
  return (
    <group>
      {[-6, -2.5, 1.5, 5, 8.5].map((x, i) => (
        <mesh key={i} position={[x, -7, -3 - i]} rotation={[0, 0, 0.12 + i * 0.02]}>
          <coneGeometry args={[2.2 + (i % 2), 14, 16, 1, true]} />
          <meshBasicMaterial color="#bff3ff" transparent opacity={o} depthWrite={false} side={THREE.DoubleSide} />
        </mesh>
      ))}
    </group>
  );
};

// ---------- Kamera dokumenter ----------
const DocCamera: React.FC<{t: number}> = ({t}) => {
  const s = easeOut(seg(t, 60.8, 61.4));
  const blink = Math.sin(t * 6) > 0 ? 1 : 0.15;
  const pos: V3 = [3.2, FLOOR + 1.0, 1.4];
  const yaw = Math.atan2(-pos[0], -pos[2]);
  return (
    <group position={pos} rotation={[0, yaw, 0]} scale={s} visible={t > 60.8 && t < 75}>
      <Toon color="#ff9f43" outline={0.06} hull={[1.07, 1.07, 1.07]}>
        <boxGeometry args={[1.2, 0.9, 1.5]} />
      </Toon>
      <Toon color="#2b3a55" position={[0, 0, 1.0]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.38, 0.44, 0.5, 18]} />
      </Toon>
      <mesh position={[0, 0, 1.27]}>
        <sphereGeometry args={[0.3, 14, 14]} />
        <meshBasicMaterial color="#7fd7ff" />
      </mesh>
      <mesh position={[0.4, 0.55, 0.4]} scale={0.1 + 0.03 * blink}>
        <sphereGeometry args={[1, 10, 10]} />
        <meshBasicMaterial color={blink > 0.5 ? '#ff3b3b' : '#702020'} />
      </mesh>
      {[-0.5, 0.5].map((x, i) => (
        <Toon key={i} color="#2b3a55" position={[x, -0.55, 0]}>
          <boxGeometry args={[0.15, 0.15, 1.6]} />
        </Toon>
      ))}
      <pointLight position={[0, 0.2, 1.5]} color="#fff4c2" intensity={10} distance={8} />
    </group>
  );
};

// ---------- Potongan: air laut membeku, garam terperas ----------
const SALTS = (() => {
  const r = rng(77);
  return Array.from({length: 30}).map(() => ({x: (r() - 0.5) * 9, y0: 0.3 + r() * 1.5, u: r(), s: 0.2 + r() * 0.14, rot: r() * 3}));
})();
const FRONT = (() => {
  const r = rng(9);
  return Array.from({length: 16}).map((_, i) => ({x: -5.2 + (i / 15) * 10.4 + (r() - 0.5) * 0.3, h: 0.35 + r() * 0.6}));
})();

const Cutaway: React.FC<{t: number}> = ({t}) => {
  const top = 2.2;
  const th = lerp(0.15, 1.7, easeOut(seg(t, 16.2, 22.6)));
  const bottom = top - th;
  const c = easeInOut(seg(t, 23, 26.7));
  const drip = easeInOut(seg(t, 27.1, 33.4)) * 3.2;
  const bAlpha = lerp(0.15, 0.85, seg(t, 18.5, 26));
  const bx = lerp(3.4, 1.0, c);
  const by = lerp(0.35, 1.5, c);
  const brineY = bottom - 0.4 - drip;
  return (
    <group position={[X0, 0, 0]}>
      {/* lapisan es yang menebal */}
      <pointLight position={[0, 1.2, 7]} color="#ffffff" intensity={30} distance={22} />
      <Toon
        color="#a9d8ec"
        emissive="#1f5d7d"
        position={[0, (7 + bottom) / 2, 0]}
        scale={[1, 7 - bottom, 1]}
        hull={[1.01, 1 + 0.07 / (7 - bottom), 1.03]}
      >
        <boxGeometry args={[14, 1, 5]} />
      </Toon>
      {FRONT.map((f, i) => {
        const g = easeOut(seg(t, 17.5, 22.6));
        return (
          <Toon key={i} color="#ffffff" outline={0.15} position={[f.x, bottom - (f.h * g) / 2, 0.4]} rotation={[Math.PI, 0, 0]} scale={[1, g + 0.001, 1]}>
            <coneGeometry args={[0.18, f.h, 6]} />
          </Toon>
        );
      })}
      {/* garam */}
      {SALTS.map((s, i) => {
        const pushed = Math.min(s.y0, bottom - 0.25 - 0.9 * s.u);
        const x = lerp(s.x, s.x * 0.25, c);
        const y = pushed - drip * c;
        return (
          <Toon key={i} color="#ffd36e" emissive="#a86a00" outline={0.2} position={[x, y, 0.3 + s.u * 0.6]} rotation={[s.rot, s.rot * 1.3, 0]}>
            <boxGeometry args={[s.s, s.s, s.s]} />
          </Toon>
        );
      })}
      {/* air asin pekat */}
      <mesh position={[0, brineY, -0.4]} scale={[bx, by, 1.2]}>
        <sphereGeometry args={[1, 24, 16]} />
        <meshToonMaterial color="#2f5bff" emissive="#1a2a8a" gradientMap={gradientMap} transparent opacity={bAlpha} />
      </mesh>
      {/* kristal embun beku di sekitar air asin */}
      {Array.from({length: 14}).map((_, i) => {
        const a = t * 0.8 + (i / 14) * Math.PI * 2;
        const o = seg(t, 27.1, 29);
        return (
          <mesh key={i} position={[Math.cos(a) * (bx + 0.6) * 0.9, brineY + Math.sin(a * 1.7) * 0.5, 0.9 + Math.sin(a) * 0.4]} scale={0.1 * o} rotation={[a, a, 0]}>
            <octahedronGeometry args={[1, 0]} />
            <meshBasicMaterial color="#ffffff" />
          </mesh>
        );
      })}
    </group>
  );
};

// ---------- Dunia ----------
export const World: React.FC<{t: number}> = ({t}) => {
  const surface = t < 3.15;
  return (
    <>
      <fog attach="fog" args={['#0a3354', surface ? 400 : 5, surface ? 800 : 38]} />
      <ambientLight intensity={0.35} />
      <hemisphereLight args={['#bfefff', '#2a6b9a', 0.8]} />
      <directionalLight position={[3, 10, 5]} intensity={1.3} color="#ffffff" />

      {surface ? <Surface /> : null}
      <IceCeiling />
      <Brinicle t={t} />
      <Jelly t={t} />
      <Floor />
      <Web t={t} />
      {CREATURES.map((_, i) => (
        <Creature key={i} i={i} t={t} />
      ))}
      <DocCamera t={t} />
      <Rays t={t} />
      <Snow t={t} center={[0, -7, 0]} size={[22, 14, 22]} />
      <Cutaway t={t} />
      <Snow t={t} center={[X0, 0.5, 1]} size={[10, 6, 6]} n={26} />
    </>
  );
};
