import React from 'react';
import {Composition} from 'remotion';
import {BrinicleVideo} from './Video';
import {DURATION_IN_FRAMES, FPS} from './timeline';

export const Root: React.FC = () => (
  <Composition
    id="Brinicle"
    component={BrinicleVideo}
    durationInFrames={DURATION_IN_FRAMES}
    fps={FPS}
    width={1080}
    height={1920}
  />
);
