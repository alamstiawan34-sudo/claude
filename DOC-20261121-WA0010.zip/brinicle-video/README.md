# Brinicle – Jari Es Kematian (Remotion, 3D toon)

Video vertikal 1080x1920, 30 fps, **2390 frame = 79,67 detik** (audio: 79,647 detik).
Audio ada di `public/narasi.mp3` dan diputar otomatis lewat `<Audio>`.

## Cara pakai
```bash
npm install
npm start          # pratinjau interaktif di Remotion Studio
npm run render     # hasil: out/brinicle.mp4 (1080x1920)
```
Chrome Headless Shell akan diunduh otomatis oleh Remotion saat render pertama.
Render butuh waktu (WebGL): sekitar 1-2 detik/frame di laptop biasa. Naikkan `--concurrency` bila CPU kuat.

## Struktur
- `src/timeline.ts`  : durasi, subtitle (CUES), jalur kamera, pertumbuhan brinicle, jaring es
- `src/World.tsx`    : seluruh dunia 3D toon (three.js + @remotion/three)
- `src/Overlay.tsx`  : subtitle, judul, termometer, viewfinder, CTA
- `src/Video.tsx`    : komposisi (audio + kamera + overlay)

## Menyesuaikan
- Timing subtitle/adegan: ubah `CUES` dan `CUTS` di `src/timeline.ts`. Waktunya dipetakan dari jeda sunyi pada audio,
  jadi pergeseran ±0,3 detik di dalam kalimat panjang mungkin terjadi.
- Rasio 16:9: ubah `width`/`height` di `src/Root.tsx` (kamera 3D menyesuaikan, posisi overlay perlu disetel ulang).
- Warna & gaya toon: `gradientMap` dan konstanta warna di `src/World.tsx`.
